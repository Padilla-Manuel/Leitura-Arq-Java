class ListaLigada{
    private Node header;
    private Node trailer;
    private int size;

    public ListaLigada(){
        //assim começa uma lista ligada com null e 0
        header = null;
        trailer = null;
        size = 0;
    }
    //para verificar se tem a lista esta vazia
    public boolean isEmpty(){
        if(size == 0)
            return true;
        else
            return false;
    }

    ///retorna o nome do animal e vai pra direita
    public Node first(){
        return header;
    }
    ///retorna o nome do animal e vai pra esquerda
    public Node last(){
        return trailer;
    }
    public int size(){
        return size;
    }
    //supor o que mna lista estiver com apenas um elemento
    //estp sirve para adicionar um elemento no inicio ou seja como o primeiro da lista
    public void addFirst(Node n){
        if(isEmpty()){
            header = n;
            trailer = n;
        }
        else{
            //o ponto é porque pertence
            n.next = header; // pato ponto proximo boi
            header = n;
        }
        size ++;

    }
    // este função adiciona para o ultimo posição
    public void addLast(Node n){
        if(isEmpty()){ ///se a lista esta vazia 
            header = n;
            trailer = n;
        }
        else{
            trailer.next = n;
            trailer = n;
        }
    }
    public void mostraLista(){
        Node aux = header;
        aux.MostraAnimal();
        while(aux != null) {
            aux = aux.next;
            aux.MostraAnimal();
        }
        System.out.println("Fim da lista : ");
        
    }
}