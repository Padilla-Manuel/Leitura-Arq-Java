public class Main{
    public static void main(String[] args)throws Exception{
        ListaLigada zoo = new ListaLigada();
        Node novo = new Node ("Gato");
        zoo.addFirst(novo);
        //2da
        zoo.addFirst(new Node("Pato"));
        zoo.addLast(new Node("Leão"));
        zoo.addFirst(new Node("Tigre"));
        zoo.addLast(new Node("Raposa"));
    }
    //System.out.println("");
}


//semana que vem vamos a remover 
// vamos inserir no meio