public class Node{
    String nomeAnimal;
    Node next;

    Node(String nomeAnimal){
        this.nomeAnimal = nomeAnimal;
        next = null;
    }    

    public void MostraAnimal(){
        System.out.println("Animal ==> " + nomeAnimal);
    }   
}